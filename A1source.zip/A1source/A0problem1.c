#include <stdio.h>

// main
int main(void){
	printf("Hello World\n");
} // end main
